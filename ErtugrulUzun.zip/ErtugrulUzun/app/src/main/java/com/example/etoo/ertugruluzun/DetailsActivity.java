package com.example.etoo.ertugruluzun;

import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        TextView ingredients = findViewById(R.id.detailPageFoodIngredients);
        TextView name = findViewById(R.id.detailPageFoodName);
        ImageView image = findViewById(R.id.detailPageImage);
        TextView forMore = findViewById(R.id.for_more);
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            return;
        }

        String foodName = extras.getString("foodName");
        String foodIngredients = extras.getString("foodIngredients");
        String foodImageUrl = extras.getString("foodImageUrl");
        final String link = extras.getString("link");
        ingredients.setText(foodIngredients);
        name.setText(foodName);
        Picasso.get().load(foodImageUrl).error(R.drawable.ic_launcher_background).into(image);

        forMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(link));
                startActivity(i);
            }
        });
    }
}
