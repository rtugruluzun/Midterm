package com.example.etoo.ertugruluzun;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/*
I created this class by following codelabs RecyclerView tutorial and yedirecycle project on gsahinpi github account
and also my previous projects.

Original code snippets can be found on link these links
https://codelabs.developers.google.com/codelabs/android-training-create-recycler-view/index.html?index=..%2F..android-training#3
https://github.com/gsahinpi/yeditepemobile18fall/blob/master/Yedirecycle.zip

*/
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ItemViewHolder> {
    ArrayList<Food> foodList;
    private LayoutInflater layoutInflater;

    public RecyclerViewAdapter(Context context, ArrayList<Food> food) {
        this.foodList = food;
        layoutInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = layoutInflater.inflate(R.layout.list_item, viewGroup, false);
        return new ItemViewHolder(v, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder itemViewHolder, int i) {
        Food currentFood = foodList.get(i);
        if (currentFood != null) {
            itemViewHolder.foodName.setText(currentFood.getFoodName());
            if (!currentFood.getFoodImageUrl().equals(""))
                Picasso.get().load(currentFood.getFoodImageUrl()).error(R.drawable.ic_launcher_background).into(itemViewHolder.foodImage);
        }
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder  {
        LinearLayout listItem;
        ImageView foodImage;
        TextView foodName;

        public ItemViewHolder(@NonNull final View itemView, RecyclerViewAdapter adapter) {
            super(itemView);
            listItem = (LinearLayout) itemView.findViewById(R.id.foodListItem);
            foodImage = (ImageView) itemView.findViewById(R.id.foodListImage);
            foodName = (TextView) itemView.findViewById(R.id.foodListName);

            listItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Food current = foodList.get(getLayoutPosition());
                    Context context = v.getContext();
                    Intent intent = new Intent(context, DetailsActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    intent.putExtra("foodName", current.getFoodName());
                    intent.putExtra("foodImageUrl", current.getFoodImageUrl());
                    intent.putExtra("foodIngredients", current.getFoodIngredients());
                    intent.putExtra("link",current.getLink());
                    context.startActivity(intent);
                }
            });
        }

    }
}
