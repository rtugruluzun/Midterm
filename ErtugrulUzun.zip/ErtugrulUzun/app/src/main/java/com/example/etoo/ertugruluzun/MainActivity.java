package com.example.etoo.ertugruluzun;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public RecyclerView recyclerList;
    private EditText searchEditText;
    private RecyclerViewAdapter rvAdapter;
    private ArrayList<Food> foodList;
    ProgressBar progressBar;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_list);
        foodList = new ArrayList<>();
        recyclerList = findViewById(R.id.recyclerList);
        searchEditText = findViewById(R.id.searchEditText);
        tv = findViewById(R.id.progressText);
        progressBar =findViewById(R.id.progressCircle);
    }

    /*
        This method is from yeditepeasync project gsahinpi's github and I have add few lines of code also
        https://github.com/gsahinpi/yeditepemobile18fall/blob/master/yeditepeasync.zip
     */

    public void searchFood(View view) {
        String queryText = searchEditText.getText().toString();
        foodList.clear();
        if (!queryText.equals("")) {
            new FetchFood(rvAdapter, foodList).execute(queryText);
            progressBar.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);

        } else Toast.makeText(this, "You should enter a word", Toast.LENGTH_SHORT).show();
    }

     /*
        This asynctask class is from yeditepeasync project gsahinpi's github and I have add few lines of code also
        https://github.com/gsahinpi/yeditepemobile18fall/blob/master/yeditepeasync.zip
     */

    public class FetchFood extends AsyncTask<String, Void, String> {
        RecyclerViewAdapter adapter;
        ArrayList<Food> foods;


        private FetchFood(RecyclerViewAdapter adapter, ArrayList<Food> food) {
            this.adapter = adapter;
            foods = food;
        }


        @Override
        protected String doInBackground(String... strings) {
            return NetworkUtils.getFoods(strings[0]);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            foods = new ArrayList<>();
            JSONObject obj;
            try {
                obj = new JSONObject(s);
                JSONArray results = obj.getJSONArray("results");
                for (int i = 0; i < results.length(); i++) {
                    JSONObject food = results.getJSONObject(i);
                    Food f = new Food();
                    f.setFoodName(food.getString("title"));
                    f.setFoodImageUrl(food.getString("thumbnail"));
                    f.setFoodIngredients(food.getString("ingredients"));
                    f.setLink(food.getString("href"));

                    Log.d("CurrentFood", food.getString("title"));

                    foods.add(f);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            adapter = new RecyclerViewAdapter(getApplicationContext(), foods);
            recyclerList.setAdapter(adapter);
            recyclerList.setHasFixedSize(true);
            recyclerList.setNestedScrollingEnabled(false);
            recyclerList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            tv.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

    }

}
