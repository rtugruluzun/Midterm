package com.example.etoo.ertugruluzun;

import android.widget.TextView;

public class Food {
    private String foodName;
    private String foodImageUrl;
    private String foodIngredients;
    private String link;
    public Food() {

    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public Food(String name, String url, String ingredients) {
        foodName = name;
        foodImageUrl = url;
        foodIngredients = ingredients;
    }

    public String getFoodIngredients() {
        return foodIngredients;
    }

    public void setFoodIngredients(String foodIngredients) {
        this.foodIngredients = foodIngredients;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodImageUrl() {
        return foodImageUrl;
    }

    public void setFoodImageUrl(String foodImageUrl) {
        this.foodImageUrl = foodImageUrl;
    }
}
